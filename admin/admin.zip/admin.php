<?php
include '../enrollment/connection.php';

if (!isset($pdo)) {
  die("Database connection is not established.");
}

$students = [];
$defaultCourse = 'BSME';

$course = isset($_GET['course']) ? $_GET['course'] : $defaultCourse;

try {
  $sql = 'SELECT * FROM students WHERE preferred_course = :course';
  $stmt = $pdo->prepare($sql);
  $stmt->bindParam(':course', $course, PDO::PARAM_STR);
  $stmt->execute();
  $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
  echo "Error: " . $e->getMessage();
  die();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SECSA Dashboard</title>
  <style>
    /* General Styles */
    body {
      margin: 0;
      padding: 0;
      font-family: 'Arial', sans-serif;
      display: flex;
      height: 100vh;
      background-color: #f8f9fa;
    }

    /* Sidebar Styles */
    .sidebar {
      width: 290px;
      background-color: #1c1622;
      color: white;
      display: flex;
      flex-direction: column;
      height: 100vh;
      align-items: center;
      justify-content: space-between;
    }

    .courses-section {
      display: flex;
      flex-direction: column;
      gap: 10px;
      align-items: center;
      margin-bottom: auto;
    }

    .btn-logout:hover {
      background-color: #e64a19;
    }

    .sidebar h2 {
      color: #ffffff;
      text-align: center;
    }

    .sidebar .courses-section {
      margin-top: 30px;
      padding-top: 10px;
    }

    .course-title {
      font-size: 18px;
      font-weight: bold;
      color: white;
      text-align: center;
      margin-bottom: 10px;
    }

    .btn-courses {
      margin: 10px 20px;
      padding: 10px;
      background-color: #ff7043;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      display: block;
      width: 80%;
    }

    .btn-courses:hover,
    .btn-logout:hover {
      background-color: #e64a19;
    }

    /* Main Content */
    .main-content {
      flex-grow: 1;
      padding: 20px;
      display: flex;
      flex-direction: column;
      gap: 20px;
      background-color: #ffffff;
    }

    .dashboard-title {
      text-align: center;
      color: #333;
    }

    /* Table Styles */
    .table-container {
      max-height: 300px;
      overflow-y: auto;
      border: 1px solid #ddd;
    }

    .student-table {
      width: 100%;
      border-collapse: collapse;
    }

    .student-table th,
    .student-table td {
      border: 1px solid #ddd;
      padding: 10px;
      text-align: center;
    }

    .student-table th {
      background-color: #8e44ad;
      color: white;
    }

    .student-table tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    .selected-course-title {
      font-size: 24px;
      font-weight: bold;
      color: #8e44ad;
      margin-bottom: 10px;
    }

    img {
      width: 125px;
      height: 100px;
    }

    .head {
      display: flex;
      align-items: center;
    }

    /* Empty Table Message */
    .no-students {
      text-align: center;
      color: #ff7043;
      font-weight: bold;
    }

    .btn-selected {
      width: 165px;
      background-color: #47395c;
      font-weight: bold;
      color: #fff;
      border: 1px solid #d84315;
      box-shadow: 0px 0px 18px 5px rgb(253 0 0 / 50%);
    }

    .btn-logout {
      width: 100%;
      margin-top: 20px;
      padding: 10px;
      background-color: #ff7043;
      color: white;
      border: none;
      border-radius: 5px;
      text-align: center;
      cursor: pointer;
      margin-bottom: 20px;
    }

    .btn-edit,
    .btn-delete {
      padding: 5px 10px;
      background-color: #3498db;
      color: white;
      border: none;
      border-radius: 3px;
      cursor: pointer;
    }

    .btn-delete {
      background-color: #e74c3c;
    }

    .btn-edit:hover {
      background-color: #2980b9;
    }

    .btn-delete:hover {
      background-color: #c0392b;
    }
  </style>
</head>

<body>

  <!-- Sidebar -->
  <aside class="sidebar">
    <h1>Courses</h1>

    <!-- Courses Section -->
    <div class="courses-section">
      <button class="btn-courses <?php echo ($course == 'BSME') ? 'btn-selected' : ''; ?>"
        onclick="filterTable('BSME')">BSME</button>
      <button class="btn-courses <?php echo ($course == 'BSEE') ? 'btn-selected' : ''; ?>"
        onclick="filterTable('BSEE')">BSEE</button>
      <button class="btn-courses <?php echo ($course == 'BSCE') ? 'btn-selected' : ''; ?>"
        onclick="filterTable('BSCE')">BSCE</button>
      <button class="btn-courses <?php echo ($course == 'BSAR') ? 'btn-selected' : ''; ?>"
        onclick="filterTable('BSAR')">BSAR</button>
      <button class="btn-courses <?php echo ($course == 'BSIT') ? 'btn-selected' : ''; ?>"
        onclick="filterTable('BSIT')">BSIT</button>
    </div>

    <form action="../index.html" method="POST">
      <button class="btn-logout">Logout</button>
    </form>
  </aside>

  <!-- Main Content -->
  <main class="main-content">
    <div class="head">
      <img src="../assets/sclogo_V1.png" alt="sc" id="sc">
      <h1 class="dashboard-title">School of Engineering, Computer Studies, and Architecture</h1>
    </div>

    <!-- Dynamic Course Title -->
    <div class="selected-course-title">
      <?php echo strtoupper($course) . " STUDENTS"; ?>
    </div>

    <!-- Student Table -->
    <div class="table-container">
      <table class="student-table">
        <thead>
          <tr>
            <th>Student ID</th>
            <th>Name</th>
            <th>Course</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="student-table-body">
          <?php
          if (count($students) > 0) {
            foreach ($students as $row) {
              echo "<tr id='student-" . $row['id'] . "'>
                      <td>" . htmlspecialchars($row['id']) . "</td>
                      <td>" . htmlspecialchars($row['firstname']) . " " . htmlspecialchars($row['lastname']) . "</td>
                      <td>" . htmlspecialchars($row['preferred_course']) . "</td>
                      <td>" . htmlspecialchars($row['email']) . "</td>
                      <td>
                        <button onclick='editStudent(" . $row['id'] . ")'>
                            <img src='../assets/edit_icon.png' alt='Edit' style='width: 20px; height: 20px; border:none;'>
                        </button>
                        <button onclick='deleteStudent(" . $row['id'] . ")'>
                            <img src='../assets/delete_icon.png' alt='Delete' style='width: 20px; height: 20px;'>
                        </button>
                      </td>
                    </tr>";
            }
          } else {
            echo "<tr><td colspan='5' class='no-students'>No students enrolled</td></tr>";
          }
          ?>
        </tbody>

      </table>
    </div>

  </main>

  <script>
    function filterTable(course) {
      window.location.href = `?course=${course}`;
    }
    function editStudent(id) {
      let row = document.getElementById('student-' + id);
      let cells = row.getElementsByTagName('td');

      let fullName = prompt("Enter new full name (First Last):", cells[1].innerText);
      let newCourse = prompt("Enter new course:", cells[2].innerText);
      let newEmail = prompt("Enter new email:", cells[3].innerText);

      let nameParts = fullName.split(' ');
      let newFirstName = nameParts[0];
      let newLastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : '';


      if (newFirstName && newLastName && newCourse && newEmail) {
        let xhr = new XMLHttpRequest();
        xhr.open("POST", "update_student.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.send(`id=${id}&firstname=${newFirstName}&lastname=${newLastName}&course=${newCourse}&email=${newEmail}`);

        // Handle server response
        xhr.onload = function () {
          let response = JSON.parse(xhr.responseText);
          if (xhr.status == 200 && response.status == 'success') {
            alert("Student updated successfully!");
            window.location.reload();
          } else {
            alert("Error updating student.");
          }
        };
      }
    }

    // Function to handle deleting a student
    function deleteStudent(id) {
      let confirmation = confirm("Are you sure you want to delete this student?");
      if (confirmation) {
        let row = document.getElementById('student-' + id);
        row.parentNode.removeChild(row);

        let xhr = new XMLHttpRequest();
        xhr.open("POST", "delete_student.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send(`id=${id}`);

        xhr.onload = function () {
          let response = JSON.parse(xhr.responseText);
          if (xhr.status == 200 && response.status == 'success') {
            alert("Student deleted successfully!");
            window.location.reload();
          } else {
            alert("Error deleting student.");
          }
        };
      }
    }


  </script>
</body>

</html>